<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Antinet Society</title>
</head>
<body>
    <h1>{{$details['title']}}</h1>
    <h2>{{$details['body']}}</h2>







    
    <p>Cheers,</p>
    <p>Antinet Society</p>
</body>
</html>