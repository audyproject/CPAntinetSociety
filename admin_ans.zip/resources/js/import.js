import "/css/examples.css"
import "/css/style.css"
import "/css/vendors/simplebar.css"
import "/vendors/simplebar/css/simplebar.css"
import "/vendors/@coreui/chartjs/css/coreui-chartjs.css"
import "/css/dataTables.bootstrap5.min.css";

// require("/js/jquery-3.5.1.js")
// // require("/vendors/@coreui/coreui/js/coreui.bundle2.min.js")
// require("/vendors/simplebar/js/simplebar.min.js")
// require("/vendors/chart.js/js/chart.min.js")
// require("/vendors/@coreui/chartjs/js/coreui-chartjs.js")
// require("/vendors/@coreui/utils/js/coreui-utils.js")
// require("/js/dataTables.bootstrap4.min.js")
// require("/js/jquery.dataTables.min.js")
// // require("/js/main.js")
// require("/js/toasts.js")